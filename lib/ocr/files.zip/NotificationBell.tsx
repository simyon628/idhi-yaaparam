"use client";

import { useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { Bell } from "lucide-react";
import {
  collection,
  query,
  where,
  orderBy,
  limit,
  onSnapshot,
  Timestamp,
} from "firebase/firestore";
import { db } from "@/lib/firebase";
import { markAsRead, markAllAsRead } from "@/lib/notifications";
import { useAuth } from "@/contexts/AuthContext"; // adjust import if needed

// ─── Types ────────────────────────────────────────────────────────────────────

interface NotificationItem {
  id: string;
  type: string;
  title: string;
  body: string;
  read: boolean;
  deepLink: string;
  createdAt: Timestamp | null;
}

// ─── Time ago helper ──────────────────────────────────────────────────────────

function timeAgo(ts: Timestamp | null): string {
  if (!ts) return "";
  const seconds = Math.floor((Date.now() - ts.toMillis()) / 1000);
  if (seconds < 60) return "just now";
  if (seconds < 3600) return `${Math.floor(seconds / 60)}m ago`;
  if (seconds < 86400) return `${Math.floor(seconds / 3600)}h ago`;
  return `${Math.floor(seconds / 86400)}d ago`;
}

// ─── Icon per notification type ───────────────────────────────────────────────

function typeIcon(type: string): string {
  switch (type) {
    case "new_message":       return "💬";
    case "rental_request":    return "📥";
    case "request_accepted":  return "✅";
    case "request_rejected":  return "❌";
    case "wishlist_available":return "🔔";
    default:                  return "📣";
  }
}

// ─── Component ────────────────────────────────────────────────────────────────

export function NotificationBell() {
  const { user } = useAuth(); // { user: FirebaseUser | null }
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const [notifications, setNotifications] = useState<NotificationItem[]>([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const dropdownRef = useRef<HTMLDivElement>(null);

  // ── Real-time listener: latest 20 notifications ───────────────────────────
  useEffect(() => {
    if (!user?.uid) return;

    const q = query(
      collection(db, "notifications"),
      where("recipientId", "==", user.uid),
      orderBy("createdAt", "desc"),
      limit(20)
    );

    const unsub = onSnapshot(
      q,
      (snap) => {
        const items: NotificationItem[] = snap.docs.map((d) => ({
          id: d.id,
          type: d.data().type ?? "",
          title: d.data().title ?? "",
          body: d.data().body ?? "",
          read: d.data().read ?? false,
          deepLink: d.data().payload?.deepLink ?? "/notifications",
          createdAt: d.data().createdAt ?? null,
        }));
        setNotifications(items);
        setUnreadCount(items.filter((n) => !n.read).length);
      },
      (err) => console.error("[NotificationBell] listener error:", err)
    );

    return () => unsub();
  }, [user?.uid]);

  // ── Close dropdown on outside click ───────────────────────────────────────
  useEffect(() => {
    function handleClick(e: MouseEvent) {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target as Node)) {
        setOpen(false);
      }
    }
    if (open) document.addEventListener("mousedown", handleClick);
    return () => document.removeEventListener("mousedown", handleClick);
  }, [open]);

  // ── Handle notification tap ────────────────────────────────────────────────
  async function handleNotificationClick(n: NotificationItem) {
    if (!n.read) await markAsRead(n.id);
    setOpen(false);
    router.push(n.deepLink);
  }

  // ── Mark all read ──────────────────────────────────────────────────────────
  async function handleMarkAllRead() {
    if (!user?.uid) return;
    await markAllAsRead(user.uid);
  }

  if (!user) return null;

  return (
    <div ref={dropdownRef} style={{ position: "relative" }}>
      {/* ── Bell button ── */}
      <button
        onClick={() => setOpen((v) => !v)}
        aria-label={`Notifications${unreadCount > 0 ? `, ${unreadCount} unread` : ""}`}
        style={{
          position: "relative",
          background: "none",
          border: "none",
          cursor: "pointer",
          padding: "8px",
          color: "var(--color-text-primary)",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          borderRadius: "var(--border-radius-md)",
        }}
      >
        <Bell size={22} />

        {/* Unread badge — Flipkart/Blinkit style */}
        {unreadCount > 0 && (
          <span
            style={{
              position: "absolute",
              top: "4px",
              right: "4px",
              minWidth: "18px",
              height: "18px",
              borderRadius: "9px",
              background: "#E53935",
              color: "#fff",
              fontSize: "11px",
              fontWeight: 600,
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              padding: "0 4px",
              lineHeight: 1,
              pointerEvents: "none",
            }}
          >
            {unreadCount > 99 ? "99+" : unreadCount}
          </span>
        )}
      </button>

      {/* ── Dropdown ── */}
      {open && (
        <div
          style={{
            position: "absolute",
            right: 0,
            top: "calc(100% + 8px)",
            width: "340px",
            maxHeight: "440px",
            overflowY: "auto",
            background: "var(--color-background-primary)",
            border: "1px solid var(--color-border-tertiary)",
            borderRadius: "var(--border-radius-lg)",
            boxShadow: "0 4px 24px rgba(0,0,0,0.12)",
            zIndex: 1000,
          }}
        >
          {/* Header */}
          <div
            style={{
              display: "flex",
              alignItems: "center",
              justifyContent: "space-between",
              padding: "14px 16px 10px",
              borderBottom: "1px solid var(--color-border-tertiary)",
            }}
          >
            <span style={{ fontSize: "15px", fontWeight: 600, color: "var(--color-text-primary)" }}>
              Notifications
            </span>
            {unreadCount > 0 && (
              <button
                onClick={handleMarkAllRead}
                style={{
                  fontSize: "12px",
                  color: "var(--color-text-info)",
                  background: "none",
                  border: "none",
                  cursor: "pointer",
                  padding: 0,
                }}
              >
                Mark all as read
              </button>
            )}
          </div>

          {/* List */}
          {notifications.length === 0 ? (
            <div
              style={{
                padding: "32px 16px",
                textAlign: "center",
                color: "var(--color-text-secondary)",
                fontSize: "14px",
              }}
            >
              No notifications yet
            </div>
          ) : (
            notifications.map((n) => (
              <button
                key={n.id}
                onClick={() => handleNotificationClick(n)}
                style={{
                  display: "flex",
                  alignItems: "flex-start",
                  gap: "10px",
                  width: "100%",
                  padding: "12px 16px",
                  background: n.read
                    ? "transparent"
                    : "var(--color-background-info)",
                  border: "none",
                  borderBottom: "1px solid var(--color-border-tertiary)",
                  cursor: "pointer",
                  textAlign: "left",
                  transition: "background 0.15s",
                }}
              >
                {/* Icon */}
                <span style={{ fontSize: "18px", flexShrink: 0, marginTop: "1px" }}>
                  {typeIcon(n.type)}
                </span>

                {/* Text */}
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div
                    style={{
                      fontSize: "13px",
                      fontWeight: n.read ? 400 : 600,
                      color: "var(--color-text-primary)",
                      marginBottom: "2px",
                      whiteSpace: "nowrap",
                      overflow: "hidden",
                      textOverflow: "ellipsis",
                    }}
                  >
                    {n.title}
                  </div>
                  <div
                    style={{
                      fontSize: "12px",
                      color: "var(--color-text-secondary)",
                      whiteSpace: "nowrap",
                      overflow: "hidden",
                      textOverflow: "ellipsis",
                    }}
                  >
                    {n.body}
                  </div>
                  <div
                    style={{
                      fontSize: "11px",
                      color: "var(--color-text-tertiary)",
                      marginTop: "4px",
                    }}
                  >
                    {timeAgo(n.createdAt)}
                  </div>
                </div>

                {/* Unread dot */}
                {!n.read && (
                  <span
                    style={{
                      width: "8px",
                      height: "8px",
                      borderRadius: "50%",
                      background: "#E53935",
                      flexShrink: 0,
                      marginTop: "5px",
                    }}
                  />
                )}
              </button>
            ))
          )}

          {/* Footer */}
          <button
            onClick={() => { setOpen(false); router.push("/notifications"); }}
            style={{
              display: "block",
              width: "100%",
              padding: "12px",
              textAlign: "center",
              fontSize: "13px",
              color: "var(--color-text-info)",
              background: "none",
              border: "none",
              borderTop: "1px solid var(--color-border-tertiary)",
              cursor: "pointer",
            }}
          >
            See all notifications
          </button>
        </div>
      )}
    </div>
  );
}
