"use client";

// lib/hooks/useFcmSetup.ts
//
// Call this hook once inside your top-level layout or _app.
// It:
//   1. Requests browser notification permission
//   2. Gets the FCM registration token
//   3. Saves it to users/{uid}.fcm_token in Firestore
//   4. Injects Firebase config into the service worker (so SW can init Firebase)
//   5. Registers the service worker

import { useEffect } from "react";
import { doc, updateDoc } from "firebase/firestore";
import { getMessaging, getToken, onMessage } from "firebase/messaging";
import { db, app as firebaseApp } from "@/lib/firebase";

const VAPID_KEY = process.env.NEXT_PUBLIC_FIREBASE_VAPID_KEY ?? "";

export function useFcmSetup(userId: string | null | undefined) {
  useEffect(() => {
    if (!userId) return;
    if (typeof window === "undefined") return;
    if (!("Notification" in window)) return;
    if (!("serviceWorker" in navigator)) return;

    let cancelled = false;

    async function setup() {
      try {
        // 1. Register service worker
        const swReg = await navigator.serviceWorker.register("/sw.js", {
          scope: "/",
        });

        if (cancelled) return;

        // 2. Inject Firebase config into SW so it can call initializeApp
        //    We post a message — SW stores it in self.__FIREBASE_CONFIG__
        const config = {
          apiKey: process.env.NEXT_PUBLIC_FIREBASE_API_KEY,
          authDomain: process.env.NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN,
          projectId: process.env.NEXT_PUBLIC_FIREBASE_PROJECT_ID,
          storageBucket: process.env.NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET,
          messagingSenderId: process.env.NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID,
          appId: process.env.NEXT_PUBLIC_FIREBASE_APP_ID,
        };

        if (swReg.active) {
          swReg.active.postMessage({ type: "FIREBASE_CONFIG", config });
        }

        // 3. Request permission
        const permission = await Notification.requestPermission();
        if (permission !== "granted" || cancelled) return;

        // 4. Get FCM token
        const messaging = getMessaging(firebaseApp);
        const token = await getToken(messaging, {
          vapidKey: VAPID_KEY,
          serviceWorkerRegistration: swReg,
        });

        if (!token || cancelled) return;

        // 5. Save token to Firestore users doc (field: fcm_token)
        await updateDoc(doc(db, "users", userId), {
          fcm_token: token,
        });

        // 6. Foreground message handler
        //    When the app tab IS focused, FCM won't show a system notification.
        //    We dispatch a custom event — NotificationBell picks it up via Firestore
        //    listener already, so we just log here.
        onMessage(messaging, (payload) => {
          console.log("[FCM] Foreground message received:", payload);
          // The Firestore onSnapshot in NotificationBell will auto-update the badge.
          // Optionally play a sound here.
        });
      } catch (err) {
        // Non-fatal — app works without push, in-app bell still works
        console.warn("[useFcmSetup] FCM setup failed (non-fatal):", err);
      }
    }

    setup();

    return () => {
      cancelled = true;
    };
  }, [userId]);
}
