import {
  collection,
  addDoc,
  serverTimestamp,
  query,
  where,
  onSnapshot,
  updateDoc,
  doc,
  writeBatch,
  getDocs,
} from "firebase/firestore";
import { db } from "@/lib/firebase";

// ─── Types ────────────────────────────────────────────────────────────────────

export type NotificationType =
  | "new_message"
  | "rental_request"
  | "request_accepted"
  | "request_rejected"
  | "wishlist_available";

export interface NotificationPayload {
  itemId?: string;
  itemName?: string;
  senderId?: string;
  senderName?: string;
  threadId?: string;
  requestId?: string;
  deepLink: string; // e.g. "/chat/abc123" or "/item/xyz"
}

export interface NotificationDoc {
  id?: string;
  recipientId: string;
  type: NotificationType;
  title: string;
  body: string;
  payload: NotificationPayload;
  read: boolean;
  createdAt: ReturnType<typeof serverTimestamp>;
}

// ─── Human-readable titles/bodies per type ────────────────────────────────────

function buildMessage(
  type: NotificationType,
  payload: NotificationPayload
): { title: string; body: string } {
  switch (type) {
    case "new_message":
      return {
        title: `New message from ${payload.senderName ?? "someone"}`,
        body: payload.itemName
          ? `About: ${payload.itemName}`
          : "Tap to open chat",
      };
    case "rental_request":
      return {
        title: "Someone wants to rent your item",
        body: payload.itemName ?? "Tap to view the request",
      };
    case "request_accepted":
      return {
        title: "Your request was accepted!",
        body: payload.itemName
          ? `${payload.itemName} is ready to pick up`
          : "Tap to see details",
      };
    case "request_rejected":
      return {
        title: "Request not accepted",
        body: payload.itemName
          ? `${payload.itemName} — tap to find alternatives`
          : "Tap to see details",
      };
    case "wishlist_available":
      return {
        title: "Item back in stock!",
        body: payload.itemName ?? "An item on your wishlist is now available",
      };
  }
}

// ─── Core: write notification doc + fire FCM push ─────────────────────────────

export async function sendNotification(
  recipientId: string,
  recipientFcmToken: string | null,
  type: NotificationType,
  payload: NotificationPayload
): Promise<void> {
  const { title, body } = buildMessage(type, payload);

  try {
    // 1. Write to Firestore (powers the in-app bell)
    await addDoc(collection(db, "notifications"), {
      recipientId,
      type,
      title,
      body,
      payload,
      read: false,
      createdAt: serverTimestamp(),
    } satisfies Omit<NotificationDoc, "id">);
  } catch (err) {
    console.error("[notifications] Firestore write failed:", err);
  }

  // 2. Fire FCM push via /api/notify (powers browser push)
  if (recipientFcmToken) {
    try {
      await fetch("/api/notify", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          token: recipientFcmToken,
          title,
          body,
          deepLink: payload.deepLink,
        }),
      });
    } catch (err) {
      console.error("[notifications] FCM push failed:", err);
      // Non-fatal — in-app bell still works without FCM push
    }
  }
}

// ─── Real-time unread count listener (for bell icon) ─────────────────────────

export function subscribeToUnreadCount(
  userId: string,
  onChange: (count: number) => void
): () => void {
  const q = query(
    collection(db, "notifications"),
    where("recipientId", "==", userId),
    where("read", "==", false)
  );

  const unsubscribe = onSnapshot(
    q,
    (snap) => onChange(snap.size),
    (err) => console.error("[notifications] listener error:", err)
  );

  return unsubscribe;
}

// ─── Mark one notification as read ───────────────────────────────────────────

export async function markAsRead(notificationId: string): Promise<void> {
  try {
    await updateDoc(doc(db, "notifications", notificationId), { read: true });
  } catch (err) {
    console.error("[notifications] markAsRead failed:", err);
  }
}

// ─── Mark ALL notifications as read for a user ───────────────────────────────

export async function markAllAsRead(userId: string): Promise<void> {
  try {
    const q = query(
      collection(db, "notifications"),
      where("recipientId", "==", userId),
      where("read", "==", false)
    );
    const snap = await getDocs(q);
    if (snap.empty) return;

    const batch = writeBatch(db);
    snap.docs.forEach((d) => batch.update(d.ref, { read: true }));
    await batch.commit();
  } catch (err) {
    console.error("[notifications] markAllAsRead failed:", err);
  }
}

// ─── Convenience wrappers (call these from feature pages) ────────────────────

/** Call after sending a chat message */
export async function notifyNewMessage(opts: {
  recipientId: string;
  recipientFcmToken: string | null;
  senderName: string;
  senderId: string;
  threadId: string;
  itemId: string;
  itemName: string;
}) {
  return sendNotification(opts.recipientId, opts.recipientFcmToken, "new_message", {
    senderId: opts.senderId,
    senderName: opts.senderName,
    threadId: opts.threadId,
    itemId: opts.itemId,
    itemName: opts.itemName,
    deepLink: `/chat/${opts.threadId}`,
  });
}

/** Call when a renter submits a rental request */
export async function notifyRentalRequest(opts: {
  recipientId: string; // item owner
  recipientFcmToken: string | null;
  senderName: string;
  requestId: string;
  itemId: string;
  itemName: string;
}) {
  return sendNotification(opts.recipientId, opts.recipientFcmToken, "rental_request", {
    senderName: opts.senderName,
    requestId: opts.requestId,
    itemId: opts.itemId,
    itemName: opts.itemName,
    deepLink: `/rentals/requests`,
  });
}

/** Call when owner accepts or rejects a request */
export async function notifyRequestDecision(opts: {
  recipientId: string; // requester
  recipientFcmToken: string | null;
  accepted: boolean;
  requestId: string;
  itemId: string;
  itemName: string;
}) {
  return sendNotification(
    opts.recipientId,
    opts.recipientFcmToken,
    opts.accepted ? "request_accepted" : "request_rejected",
    {
      requestId: opts.requestId,
      itemId: opts.itemId,
      itemName: opts.itemName,
      deepLink: opts.accepted ? `/item/${opts.itemId}` : `/rentals`,
    }
  );
}

/** Call when a wishlisted item becomes available */
export async function notifyWishlistAvailable(opts: {
  recipientId: string;
  recipientFcmToken: string | null;
  itemId: string;
  itemName: string;
}) {
  return sendNotification(opts.recipientId, opts.recipientFcmToken, "wishlist_available", {
    itemId: opts.itemId,
    itemName: opts.itemName,
    deepLink: `/item/${opts.itemId}`,
  });
}
