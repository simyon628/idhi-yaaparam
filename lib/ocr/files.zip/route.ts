import { NextRequest, NextResponse } from "next/server";

// ─── Firebase FCM REST endpoint ───────────────────────────────────────────────
// Uses Firebase HTTP v1 API — no Admin SDK, no service account JSON file.
// Auth is done via a short-lived access token obtained from the service account
// credentials stored as a single Vercel env var: FIREBASE_SERVICE_ACCOUNT_JSON
//
// Required Vercel env vars:
//   NEXT_PUBLIC_FIREBASE_PROJECT_ID  (already set)
//   FIREBASE_SERVICE_ACCOUNT_JSON    (new — paste the full service account JSON)

interface NotifyRequest {
  token: string;    // FCM registration token of recipient device
  title: string;
  body: string;
  deepLink: string; // e.g. "/chat/abc123"
}

// ─── Get a short-lived OAuth2 access token from service account creds ─────────

async function getFcmAccessToken(): Promise<string> {
  const raw = process.env.FIREBASE_SERVICE_ACCOUNT_JSON;
  if (!raw) throw new Error("FIREBASE_SERVICE_ACCOUNT_JSON env var is not set");

  const sa = JSON.parse(raw);

  const now = Math.floor(Date.now() / 1000);
  const header = { alg: "RS256", typ: "JWT" };
  const payload = {
    iss: sa.client_email,
    sub: sa.client_email,
    aud: "https://oauth2.googleapis.com/token",
    iat: now,
    exp: now + 3600,
    scope: "https://www.googleapis.com/auth/firebase.messaging",
  };

  // Encode header + payload
  const encode = (obj: object) =>
    Buffer.from(JSON.stringify(obj))
      .toString("base64")
      .replace(/=/g, "")
      .replace(/\+/g, "-")
      .replace(/\//g, "_");

  const unsigned = `${encode(header)}.${encode(payload)}`;

  // Sign with RSA-SHA256 using the private key from service account
  const { createSign } = await import("crypto");
  const sign = createSign("RSA-SHA256");
  sign.update(unsigned);
  const signature = sign
    .sign(sa.private_key, "base64")
    .replace(/=/g, "")
    .replace(/\+/g, "-")
    .replace(/\//g, "_");

  const jwt = `${unsigned}.${signature}`;

  // Exchange JWT for access token
  const tokenRes = await fetch("https://oauth2.googleapis.com/token", {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({
      grant_type: "urn:ietf:params:oauth2:grant-type:jwt-bearer",
      assertion: jwt,
    }),
  });

  if (!tokenRes.ok) {
    const err = await tokenRes.text();
    throw new Error(`OAuth token exchange failed: ${err}`);
  }

  const tokenData = await tokenRes.json();
  return tokenData.access_token as string;
}

// ─── Route handler ─────────────────────────────────────────────────────────────

export async function POST(req: NextRequest) {
  try {
    const body = (await req.json()) as NotifyRequest;
    const { token, title, body: msgBody, deepLink } = body;

    if (!token || !title) {
      return NextResponse.json({ error: "token and title are required" }, { status: 400 });
    }

    const projectId = process.env.NEXT_PUBLIC_FIREBASE_PROJECT_ID;
    if (!projectId) {
      return NextResponse.json({ error: "Firebase project ID not configured" }, { status: 500 });
    }

    const accessToken = await getFcmAccessToken();

    const fcmRes = await fetch(
      `https://fcm.googleapis.com/v1/projects/${projectId}/messages:send`,
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${accessToken}`,
        },
        body: JSON.stringify({
          message: {
            token,
            notification: {
              title,
              body: msgBody,
            },
            webpush: {
              notification: {
                title,
                body: msgBody,
                icon: "/icons/icon-192x192.png",
                badge: "/icons/badge-72x72.png",
                click_action: deepLink,
                // Flipkart/Blinkit style: vibrate on receipt
                vibrate: [200, 100, 200],
              },
              fcm_options: {
                link: deepLink,
              },
            },
            // Android channel for future app expansion
            android: {
              notification: {
                channel_id: "idhi_yaaparam_default",
                click_action: "FLUTTER_NOTIFICATION_CLICK",
              },
            },
            // Custom data for deep link handling in SW
            data: {
              deepLink,
              title,
              body: msgBody,
            },
          },
        }),
      }
    );

    if (!fcmRes.ok) {
      const err = await fcmRes.json();
      console.error("[/api/notify] FCM error:", err);
      // Return 200 anyway — Firestore write already happened, push is best-effort
      return NextResponse.json({ warning: "FCM push failed", detail: err }, { status: 200 });
    }

    const result = await fcmRes.json();
    return NextResponse.json({ success: true, messageId: result.name });
  } catch (err) {
    console.error("[/api/notify] Unexpected error:", err);
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    );
  }
}
