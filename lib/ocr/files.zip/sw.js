// public/sw.js
// Idhi Yaaparam — Service Worker
//
// RULES (do not break these — see project bug log):
//   1. Never intercept POST requests
//   2. Never intercept /api routes
//   3. Never intercept Firebase SDK requests
//   4. Only handle: background FCM push + notification click deep links

importScripts("https://www.gstatic.com/firebasejs/10.7.1/firebase-app-compat.js");
importScripts("https://www.gstatic.com/firebasejs/10.7.1/firebase-messaging-compat.js");

// ─── Firebase init (must match your env vars) ─────────────────────────────────
firebase.initializeApp({
  apiKey: self.__FIREBASE_CONFIG__?.apiKey ?? "",
  authDomain: self.__FIREBASE_CONFIG__?.authDomain ?? "",
  projectId: self.__FIREBASE_CONFIG__?.projectId ?? "idhi-yaaparam",
  storageBucket: self.__FIREBASE_CONFIG__?.storageBucket ?? "",
  messagingSenderId: self.__FIREBASE_CONFIG__?.messagingSenderId ?? "",
  appId: self.__FIREBASE_CONFIG__?.appId ?? "",
});

const messaging = firebase.messaging();

// ─── Background push handler ──────────────────────────────────────────────────
// Fires when a push arrives and the app tab is NOT in focus.
// FCM payload from /api/notify has notification + data fields.

messaging.onBackgroundMessage((payload) => {
  const { title, body } = payload.notification ?? {};
  const deepLink = payload.data?.deepLink ?? "/";

  if (!title) return;

  self.registration.showNotification(title, {
    body: body ?? "",
    icon: "/icons/icon-192x192.png",
    badge: "/icons/badge-72x72.png",
    // Store deepLink so notificationclick can use it
    data: { deepLink },
    // Flipkart/Blinkit style vibration
    vibrate: [200, 100, 200],
    // Show even if same notification is already showing
    tag: deepLink,
    renotify: true,
    // Keep notification visible until user taps (don't auto-dismiss)
    requireInteraction: false,
    actions: [
      { action: "open", title: "Open" },
      { action: "dismiss", title: "Dismiss" },
    ],
  });
});

// ─── Notification click → open deep link ──────────────────────────────────────
self.addEventListener("notificationclick", (event) => {
  event.notification.close();

  if (event.action === "dismiss") return;

  const deepLink = event.notification.data?.deepLink ?? "/";
  const targetUrl = new URL(deepLink, self.location.origin).href;

  event.waitUntil(
    clients
      .matchAll({ type: "window", includeUncontrolled: true })
      .then((windowClients) => {
        // If the app is already open, focus it and navigate
        for (const client of windowClients) {
          if (client.url.startsWith(self.location.origin) && "focus" in client) {
            client.focus();
            client.navigate(targetUrl);
            return;
          }
        }
        // Otherwise open a new tab
        if (clients.openWindow) {
          return clients.openWindow(targetUrl);
        }
      })
  );
});

// ─── Fetch handler — CRITICAL: do NOT intercept API or Firebase calls ─────────
self.addEventListener("fetch", (event) => {
  const url = new URL(event.request.url);

  // Skip: non-GET requests (POST, PUT, DELETE etc.)
  if (event.request.method !== "GET") return;

  // Skip: /api routes
  if (url.pathname.startsWith("/api/")) return;

  // Skip: Firebase domains
  if (
    url.hostname.includes("firebaseapp.com") ||
    url.hostname.includes("googleapis.com") ||
    url.hostname.includes("firebasestorage.app") ||
    url.hostname.includes("fcm.googleapis.com")
  ) {
    return;
  }

  // Skip: Chrome extension requests
  if (url.protocol === "chrome-extension:") return;

  // For all other GET requests: network-first, no caching
  // (keeps app always fresh — important for campus marketplace)
  event.respondWith(fetch(event.request));
});

// ─── SW lifecycle ─────────────────────────────────────────────────────────────
self.addEventListener("install", () => self.skipWaiting());
self.addEventListener("activate", (event) => {
  event.waitUntil(clients.claim());
});
